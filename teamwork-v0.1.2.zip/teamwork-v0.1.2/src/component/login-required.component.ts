import Vue from 'vue';
import Component from 'vue-class-component'

@Component({
    template: require('./login-required.component.html')
})
export class LoginRequiredComponent extends Vue {
}
