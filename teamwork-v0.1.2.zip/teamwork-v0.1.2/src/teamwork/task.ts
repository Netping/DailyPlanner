export interface Task {
    id: number;
    name: string;
    url: string;
    time_estimated: number;
    time_day_log: number;
}
